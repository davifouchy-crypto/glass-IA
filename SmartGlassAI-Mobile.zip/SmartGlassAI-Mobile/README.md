# SmartGlass AI - versão mobile

Esta versão transforma o protótipo Python em uma aplicação web mobile que roda no navegador do celular.

## O que já faz

- câmera frontal em tempo real;
- MediaPipe Face Landmarker no navegador;
- detecção de 478 landmarks faciais;
- estimativa geométrica do formato do rosto;
- recomendação automática de armação;
- seis tipos de armação desenhados diretamente no canvas;
- acompanhamento do movimento do rosto;
- modo manual e modo automático;
- painel explicando a recomendação;
- modo de visualização dos landmarks;
- fallback de GPU para CPU;
- interface responsiva para celular;
- PWA básico para instalação na tela inicial.

## Como testar

1. Coloque a pasta em um servidor web.
2. Abra pelo celular usando HTTPS.
3. Permita o acesso à câmera.
4. Fique de frente para a câmera.

Para um teste local no computador, use um servidor HTTP local. O acesso à câmera em navegador normalmente exige um contexto seguro (HTTPS) ou localhost.

## Estrutura

- `index.html` = interface
- `styles.css` = visual
- `app.js` = câmera + MediaPipe + classificação + overlay dos óculos
- `manifest.json` = configuração PWA
- `sw.js` = cache básico do app

## Observação técnica

O MediaPipe faz a parte de visão computacional com um modelo pré-treinado. A classificação do formato do rosto e a compatibilidade das armações nesta primeira versão são regras heurísticas do projeto.

A próxima evolução é substituir essa heurística por um modelo de Machine Learning treinado com características faciais e rótulos definidos pelo projeto.
