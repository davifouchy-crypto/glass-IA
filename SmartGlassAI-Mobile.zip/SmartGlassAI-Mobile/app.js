import { FilesetResolver, FaceLandmarker } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.0.1/+esm";

const MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.0.1/wasm";

const video = document.getElementById("camera");
const canvas = document.getElementById("overlay");
const ctx = canvas.getContext("2d");
const statusEl = document.getElementById("status");
const loadingEl = document.getElementById("loading");
const noFaceEl = document.getElementById("no-face");
const shapeEl = document.getElementById("face-shape");
const glassesNameEl = document.getElementById("glasses-name");
const scoreEl = document.getElementById("score");
const reasonEl = document.getElementById("reason");
const autoBtn = document.getElementById("auto-btn");
const landmarksBtn = document.getElementById("landmarks-btn");
const glassButtons = [...document.querySelectorAll("[data-glasses]")];

let faceLandmarker = null;
let stream = null;
let running = false;
let autoMode = true;
let showLandmarks = false;
let manualGlasses = "retangular";
let lastVideoTime = -1;
let lastInference = 0;
let latestResult = null;
let latestShape = null;
let latestMeasurements = null;

const GLASSES = {
  redondo: "Redondo",
  quadrado: "Quadrado",
  retangular: "Retangular",
  aviador: "Aviador",
  geometrico: "Geométrico",
  oval: "Oval",
};

const RECOMMENDATIONS = {
  oval: [["retangular", 92], ["quadrado", 84], ["geometrico", 78]],
  redondo: [["retangular", 92], ["quadrado", 88], ["geometrico", 82]],
  quadrado: [["redondo", 92], ["oval", 88], ["aviador", 82]],
  retangular: [["redondo", 91], ["oval", 87], ["aviador", 82]],
};

const LANDMARKS = {
  leftIris: 468,
  rightIris: 473,
  forehead: 10,
  chin: 152,
  cheekLeft: 234,
  cheekRight: 454,
};

function setStatus(text) {
  statusEl.textContent = text;
}

function dist(a, b) {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

function classifyFace(landmarks) {
  const width = dist(landmarks[LANDMARKS.cheekLeft], landmarks[LANDMARKS.cheekRight]);
  const height = dist(landmarks[LANDMARKS.forehead], landmarks[LANDMARKS.chin]);
  const ratio = height > 0 ? width / height : 0.75;

  let shape;
  if (ratio >= 0.84) shape = "redondo";
  else if (ratio >= 0.76) shape = "quadrado";
  else if (ratio >= 0.68) shape = "oval";
  else shape = "retangular";

  return { shape, width, height, ratio };
}

function bestRecommendations(shape) {
  return RECOMMENDATIONS[shape] ?? RECOMMENDATIONS.oval;
}

function currentScore(shape, glasses) {
  const item = bestRecommendations(shape).find(([name]) => name === glasses);
  return item ? item[1] : 68;
}

function reasonText(shape, glasses) {
  const score = currentScore(shape, glasses);
  if (score >= 90) return "Boa compatibilidade segundo as proporções geométricas usadas pelo protótipo.";
  if (score >= 80) return "Compatibilidade alta segundo as regras heurísticas do protótipo.";
  return "Esta armação ficou fora das três primeiras recomendações para este formato facial.";
}

function updateControls(activeGlasses) {
  glassButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.glasses === activeGlasses && !autoMode);
  });
  autoBtn.classList.toggle("active", autoMode);
}

function getFacePoints(face) {
  const keys = Object.keys(LANDMARKS);
  const points = {};
  for (const key of keys) {
    const index = LANDMARKS[key];
    if (!face[index]) return null;
    points[key] = face[index];
  }
  return points;
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(rect.width * dpr);
  canvas.height = Math.round(rect.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function mapPoint(p) {
  // O canvas inteiro é espelhado via CSS para acompanhar a câmera frontal.
  // Portanto, aqui usamos diretamente as coordenadas normalizadas do MediaPipe.
  return {
    x: p.x * canvas.clientWidth,
    y: p.y * canvas.clientHeight,
  };
}

function roundedRectPath(ctx, x, y, w, h, r) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

function drawLens(cx, cy, rx, ry, type) {
  ctx.beginPath();
  if (type === "redondo") {
    ctx.ellipse(cx, cy, ry > rx ? ry : rx, ry > rx ? rx : ry, 0, 0, Math.PI * 2);
  } else if (type === "oval") {
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  } else if (type === "aviador") {
    // Uma forma inspirada no formato de aviador, sem usar arte de terceiros.
    ctx.moveTo(cx, cy - ry);
    ctx.quadraticCurveTo(cx + rx, cy - ry * .85, cx + rx * .88, cy + ry * .55);
    ctx.quadraticCurveTo(cx, cy + ry * 1.12, cx - rx * .88, cy + ry * .55);
    ctx.quadraticCurveTo(cx - rx, cy - ry * .85, cx, cy - ry);
    ctx.closePath();
  } else if (type === "geometrico") {
    ctx.moveTo(cx - rx * .85, cy - ry * .55);
    ctx.lineTo(cx + rx * .65, cy - ry * .8);
    ctx.lineTo(cx + rx, cy + ry * .35);
    ctx.lineTo(cx + rx * .2, cy + ry);
    ctx.lineTo(cx - rx, cy + ry * .35);
    ctx.closePath();
  } else {
    roundedRectPath(ctx, cx - rx, cy - ry, rx * 2, ry * 2, type === "retangular" ? ry * .28 : ry * .38);
  }
  ctx.stroke();
}

function drawGlasses(points, glassesName) {
  const left = mapPoint(points.leftIris);
  const right = mapPoint(points.rightIris);
  const dx = right.x - left.x;
  const dy = right.y - left.y;
  const eyeDistance = Math.max(22, Math.hypot(dx, dy));
  const angle = Math.atan2(dy, dx);

  const centerX = (left.x + right.x) / 2;
  const centerY = (left.y + right.y) / 2 + eyeDistance * 0.04;
  const offset = eyeDistance * 0.50;

  const leftCX = centerX - offset;
  const rightCX = centerX + offset;
  const lensRX = eyeDistance * 0.42;
  let lensRY;
  switch (glassesName) {
    case "redondo": lensRY = lensRX * .94; break;
    case "oval": lensRY = lensRX * .70; break;
    case "retangular": lensRY = lensRX * .58; break;
    case "quadrado": lensRY = lensRX * .76; break;
    case "geometrico": lensRY = lensRX * .72; break;
    case "aviador": lensRY = lensRX * .86; break;
    default: lensRY = lensRX * .72;
  }

  const rim = Math.max(2.2, eyeDistance * .025);
  ctx.save();
  ctx.translate(centerX, centerY);
  ctx.rotate(angle);
  ctx.strokeStyle = "rgba(18,20,23,.96)";
  ctx.lineWidth = rim;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";

  drawLens(-offset, 0, lensRX, lensRY, glassesName);
  drawLens(offset, 0, lensRX, lensRY, glassesName);

  ctx.lineWidth = Math.max(2, rim * .8);
  ctx.beginPath();
  ctx.moveTo(-lensRX * .18, 0);
  ctx.quadraticCurveTo(0, -lensRY * .15, lensRX * .18, 0);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-offset - lensRX * .82, 0);
  ctx.lineTo(-offset - lensRX * 1.45, 0);
  ctx.moveTo(offset + lensRX * .82, 0);
  ctx.lineTo(offset + lensRX * 1.45, 0);
  ctx.stroke();

  // Lentes translúcidas para dar um efeito visual melhor.
  ctx.fillStyle = "rgba(210,230,255,.08)";
  ctx.fill();

  ctx.restore();
}

function drawLandmarks(points) {
  const pts = Object.values(points).map(mapPoint);
  ctx.fillStyle = "#7cff8a";
  for (const p of pts) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, 3.2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawResult() {
  if (!latestResult || !latestResult.faceLandmarks?.length) {
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
    noFaceEl.classList.remove("hidden");
    return;
  }

  noFaceEl.classList.add("hidden");
  ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
  const face = latestResult.faceLandmarks[0];
  const points = getFacePoints(face);
  if (!points) return;

  const activeGlasses = autoMode
    ? bestRecommendations(latestShape)[0][0]
    : manualGlasses;

  drawGlasses(points, activeGlasses);
  if (showLandmarks) drawLandmarks(points);
}

function updateUi() {
  if (!latestShape) return;
  const activeGlasses = autoMode
    ? bestRecommendations(latestShape.shape)[0][0]
    : manualGlasses;
  const score = currentScore(latestShape.shape, activeGlasses);

  shapeEl.textContent = latestShape.shape.toUpperCase();
  glassesNameEl.textContent = GLASSES[activeGlasses];
  scoreEl.textContent = `${score}%`;
  reasonEl.textContent = reasonText(latestShape.shape, activeGlasses);
  updateControls(activeGlasses);
}

async function createLandmarker() {
  const vision = await FilesetResolver.forVisionTasks(WASM_URL);
  try {
    return await FaceLandmarker.createFromOptions(vision, {
      baseOptions: { modelAssetPath: MODEL_URL, delegate: "GPU" },
      runningMode: "VIDEO",
      numFaces: 1,
      minFaceDetectionConfidence: .5,
      minFacePresenceConfidence: .5,
      minTrackingConfidence: .5,
      outputFaceBlendshapes: false,
      outputFacialTransformationMatrixes: false,
    });
  } catch (gpuError) {
    console.warn("GPU não disponível; usando CPU.", gpuError);
    return await FaceLandmarker.createFromOptions(vision, {
      baseOptions: { modelAssetPath: MODEL_URL, delegate: "CPU" },
      runningMode: "VIDEO",
      numFaces: 1,
      minFaceDetectionConfidence: .5,
      minFacePresenceConfidence: .5,
      minTrackingConfidence: .5,
      outputFaceBlendshapes: false,
      outputFacialTransformationMatrixes: false,
    });
  }
}

async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Este navegador não oferece acesso à câmera neste contexto. Use HTTPS ou localhost.");
  }

  stream = await navigator.mediaDevices.getUserMedia({
    audio: false,
    video: {
      facingMode: { ideal: "user" },
      width: { ideal: 720 },
      height: { ideal: 960 },
      frameRate: { ideal: 30, max: 30 },
    },
  });
  video.srcObject = stream;
  await video.play();
}

function loop(now) {
  if (!running) return;
  requestAnimationFrame(loop);

  if (video.readyState < 2 || !faceLandmarker) return;
  if (video.currentTime === lastVideoTime) {
    drawResult();
    return;
  }

  // Limita a inferência para aliviar celulares mais fracos.
  if (now - lastInference < 55) {
    drawResult();
    return;
  }

  lastVideoTime = video.currentTime;
  lastInference = now;

  try {
    latestResult = faceLandmarker.detectForVideo(video, now);
    if (latestResult.faceLandmarks?.length) {
      latestShape = classifyFace(latestResult.faceLandmarks[0]);
      latestMeasurements = latestShape;
      updateUi();
    }
    drawResult();
  } catch (error) {
    console.error(error);
    setStatus("Erro no processamento");
  }
}

glassButtons.forEach((button) => {
  button.addEventListener("click", () => {
    manualGlasses = button.dataset.glasses;
    autoMode = false;
    updateUi();
    drawResult();
  });
});

autoBtn.addEventListener("click", () => {
  autoMode = !autoMode;
  updateUi();
  drawResult();
});

landmarksBtn.addEventListener("click", () => {
  showLandmarks = !showLandmarks;
  landmarksBtn.textContent = showLandmarks ? "Esconder landmarks" : "Mostrar landmarks";
  drawResult();
});

window.addEventListener("resize", resizeCanvas);

async function main() {
  try {
    resizeCanvas();
    setStatus("Carregando IA...");
    faceLandmarker = await createLandmarker();

    setStatus("Solicitando câmera...");
    await startCamera();

    loadingEl.classList.add("hidden");
    setStatus("IA ativa");
    running = true;
    requestAnimationFrame(loop);
  } catch (error) {
    console.error(error);
    loadingEl.innerHTML = `
      <strong>Não foi possível iniciar.</strong>
      <span>${error?.message || "Verifique a permissão da câmera."}</span>
    `;
    setStatus("Falha ao iniciar");
  }
}

window.addEventListener("beforeunload", () => {
  stream?.getTracks().forEach(track => track.stop());
  faceLandmarker?.close();
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(console.warn);
}

main();
